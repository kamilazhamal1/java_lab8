package zhkb17_junit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static javafxapplication.FXMLDocumentController.equa;

public class JUnitTest {

    @Test
    public void testFXML() throws Exception {
        assertTrue(equa(2, 0, 0) == 4.00);
        assertTrue(equa(2, 2, 8) == 1048.00);
        assertTrue(equa(10, 10, 8) == 1464.00);
    }

}
